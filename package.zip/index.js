const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const adminRoutes = require('./routes/admin');
const indexRoutes = require('./routes/index');
const shopRoutes = require('./routes/shop');
const mongoose = require('mongoose');
const User = require('./models/users')


app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

// app.use((req, res, next) => {
//   User.findById('640e752a0638c28b69abae40')
//     .then(user => {
//       req.user = user;
//       next();
//     })
//     .catch(err => console.log(err));
// });

app.use('/admin', adminRoutes);
app.use('/shop', shopRoutes);
app.use('/', indexRoutes);


mongoose.set('strictQuery', true);
mongoose.connect('mongodb+srv://agitamaputr:12345@cluster0.9jlrzsr.mongodb.net/test')
.then(result => {
  User.findOne().then(user => {
    if (!user) {
      const user = new User({
        name: 'adi',
        email: 'adi@kodingakademi.com',
        cart: {
          items: []
        }
      });
      user.save();
    }
  });
  
  app.listen(8000, () => {
    console.log(`"Connected" listening at http://localhost:8000`)
  });
})
.catch(err => {
  console.log(err);
});