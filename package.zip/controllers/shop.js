const Product = require('../models/product')


exports.getProducts = (req,res,next) => {
   Product.find({ title: /Kemeja/i, price: { $gte: 60000}})
    .then(products => {
        console.log(products)
        res.json({products})
    })
    .catch(err => console.log(err))
  };

  exports.getIndex = (req,res,next) => {
    Product.find()
    .then(products => {
      res.json({data : products})
    })
    .catch(err => console.log(err))
  }
  