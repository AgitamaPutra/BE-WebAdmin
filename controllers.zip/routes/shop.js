const express = require("express");
// const productsController = require('../controllers/products');
const router = express.Router();
const shopController = require("../controllers/shop");

router.get("/products", shopController.getProducts);
router.post("/cart", shopController.postCart);
router.get("/carts", shopController.getCart);
router.get("/clear", shopController.clearCart);
router.post("/remove", shopController.removeItems);
// router.get('/', shopController.getIndex);
// router.get('/product/:id', shopController.getProduct )
// router.get('/product/:id/delete', productsController.postDeleteProduct )
// router.post('/addtocart' , shopController.postAddCart)
// router.post('/cartitems/delete', shopController.postCartDeleteProduct)
// router.post('/create-order', shopController.postOrder)
// console.log(shopController)

module.exports = router;
