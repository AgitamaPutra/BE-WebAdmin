const Product = require('../models/product')



exports.getProducts = (req,res,next) => {
   Product.find({ title: /Kemeja/i, price: { $gte: 60000}})
    .then(products => {
        console.log(products)
        res.json({products})
    })
    .catch(err => console.log(err))
  };

  exports.getIndex = (req,res,next) => {
    Product.find()
    .then(products => {
      res.json({data : products})
    })
    .catch(err => console.log(err))
  }

  exports.postCart = (req,res,next) => {
    const prodId = req.body.productId;
    Product.findById(prodId)
    .then(product =>{
      return req.user.addToCart(product)
    })
    .then(result => {
      console.log(result)
      res.json(result)
    })
  }
  
  exports.getCart = (req,res,next) => {
    req.user.populate('cart.items.productId', )
    .then(products => {
      res.json(products)
    })
    .catch(err => console.log(err))
  }

  exports.clearCart = (req,res,next) => {
    const cart = (req.user.clearCart())
    res.json(cart)
  }

  exports.removeItems = (req,res,next) => {
    const prodId = req.body.productId
    Product.findById("640f1554c5df57574178e782")
    .then(product => {
      console.log(product)
      const items = req.user.removeItems(product)
      res.json(items)
    
    }) 

  }
